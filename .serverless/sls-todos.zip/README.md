# sls-todo
Sample of Serverless Framework + Express.

## usage
